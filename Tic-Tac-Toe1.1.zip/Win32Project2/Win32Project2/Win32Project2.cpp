// Win32Project2.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Win32Project2.h"
#include <windowsx.h>

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.

    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WIN32PROJECT2, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WIN32PROJECT2));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WIN32PROJECT2));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    //wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
	wcex.hbrBackground = (HBRUSH)(GetStockObject(GRAY_BRUSH));
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_WIN32PROJECT2);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//Global variables
const int CELL_SIZE = 100;
HBRUSH hbr1, hbr2, hbr3;
int playerTurn = 1;
int mode = 0;
int gameBoard[25] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
int winner = 0;
int wins[4];
int cells[] = { 0,1,2,3, 1,2,3,4, 5,6,7,8, 6,7,8,9, 10,11,12,13, 11,12,13,14, 15,16,17,18, 16,17,18,19, 20,21,22,23, 21,22,23,24,
0,6,12,18, 6,12,18,24, 1,7,13,19, 5,11,17,23, 4,8,12,16, 8,12,16,20, 9,13,17,21, 3,7,11,15,
0,5,10,15, 5,10,15,20, 1,6,11,16, 6,11,16,21, 2,7,12,17, 7,12,17,22, 3,8,13,18, 8,13,18,23, 4,9,14,19, 9,14,19,24 };
const WCHAR szPlayer1[] = L"Player 1";
const WCHAR szPlayer2[] = L"Player 2";
const WCHAR szPlayer3[] = L"AI";
int index;
int count = 0;
int AI;
BOOL GetGameBoard(HWND hWnd, RECT * pRect)
{

	RECT rc;
	if (GetClientRect(hWnd, &rc))
	{
		int width = rc.right - rc.left;
		int height = rc.bottom - rc.top;

		pRect -> left = (width - CELL_SIZE * 5) / 2;
		pRect-> top = (height - CELL_SIZE * 5) / 2;

		pRect-> right = (pRect->left + CELL_SIZE * 5);
		pRect-> bottom = (pRect->top + CELL_SIZE * 5);
		return TRUE;
	}

	SetRectEmpty(pRect);
	return FALSE;
}

void Drawlines(HDC hdc, int x1, int y1, int x2, int y2)
{
	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
}

int GetCellNumberFromPoint(HWND hwnd, int x, int y)
{
	POINT pt = { x, y };
	RECT rc;

	if (GetGameBoard(hwnd, &rc))
	{
		if (PtInRect(&rc, pt))
		{
			//use clicks in the board
			x = pt.x - rc.left;
			y = pt.y  - rc.top;
		
			int column = x / CELL_SIZE;
			int row = y  / CELL_SIZE ;

			return (column + row * 5);
		}
	}
	//outside tic-tac-toe board
	return -1;
}

BOOL GetCellRect( HWND hWnd, int index, RECT *pRect)
{
	RECT rcBoard;
	SetRectEmpty(pRect);
	if (index < 0 || index > 24)
		return FALSE;
	if (GetGameBoard(hWnd, &rcBoard))
	{
		int y = index / 5;
		int x = index % 5;

		pRect->left = rcBoard.left + x * CELL_SIZE + 10;
		pRect->top = rcBoard.top + y * CELL_SIZE + 10;
		pRect->right = pRect->left + CELL_SIZE - 20;
		pRect->bottom = pRect->top + CELL_SIZE - 20;

		return TRUE;
	}
	return FALSE;
	}

//returns the winner
/*
00-01-02-03-04
05-06-07-08-09
10-11-12-13-14
15-16-17-18-19
20-21-22-23-24
*/
int Winner(int wins[4])
{
	//row, verticals, columns
	
	for (int i = 0; i < ARRAYSIZE(cells); i += 4)
	{
		if (0 != gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 1]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && gameBoard[cells[i]] == gameBoard[cells[i + 3]])
		{
			wins[0] = cells[i];
			wins[1] = cells[i + 1];
			wins[2] = cells[i + 2];

			return gameBoard[cells[i]];
		}
	}

	for (int i = 0; i < ARRAYSIZE(gameBoard); ++i)
	{
		if (0 == gameBoard[i])
			return 0;
	}

	return 3;
}
void ShowTurn(HWND hWnd, HDC hdc)
{
	const WCHAR * TurnText = NULL;

	switch (winner)
	{
		case 0:	
			if (mode == 0)
			{
				TurnText = (playerTurn == 1) ? szPlayer1 : szPlayer2;
			}
			if (mode != 0)
			{
				TurnText = (playerTurn == 1) ? szPlayer1 : szPlayer3;
			}
			
			break;
		case 1:
			TurnText = L"Player 1 is the winnner!";
			break;
		case 2:
			TurnText = L"Player 2 is the winnner!";
			break;
		case 3:
			TurnText = L"It's a draw!";
			break;
		case 4:
			TurnText = L"AI is the winnner!";
			break;

	}
	RECT rc;
	if (NULL != TurnText && GetClientRect(hWnd, &rc))
	{
		rc.top = rc.bottom - 48;
		FillRect(hdc, &rc, (HBRUSH)GetStockObject(GRAY_BRUSH));
		SetTextColor(hdc, RGB(255, 255, 255));
		SetBkMode(hdc, TRANSPARENT);


		DrawText(hdc,TurnText, lstrlen(TurnText), &rc, DT_CENTER);
	}
}

void Moves(HWND hWnd, HDC hdc, int xPos, int yPos)
{
	if (mode == 0)
	{
		//calling function for button
		index = GetCellNumberFromPoint(hWnd, xPos, yPos);

		//print out Value of cell clicked on
		if (NULL != hdc)
		{
			/*WCHAR temp[100];
			wsprintf(temp, L"Index = %d", index);
			TextOut(hdc, xPos, yPos, temp, lstrlen(temp));*/
			//get cell demensions
			if (index != -1)
			{
				RECT rcCell;

				//cell is taken no other player can take over
				if ((0 == gameBoard[index]) && GetCellRect(hWnd, index, &rcCell))
				{
					gameBoard[index] = playerTurn;
					FillRect(hdc, &rcCell, (playerTurn == 2) ? hbr2 : hbr1);
					//FillRect(hdc, &rcCell, hbr1);
					winner = Winner(wins);
					if (winner == 1 || winner == 2)
					{
						MessageBox(hWnd, (winner == 1) ? L"Player 1 is the winnner!" : L"Player 2 is the winner!", L"You Win!", MB_OK | MB_ICONINFORMATION);
						playerTurn = 0;

					}

					else if (3 == winner)
					{
						MessageBox(hWnd, L"No one wins!", L"It's a draw", MB_OK | MB_ICONEXCLAMATION);
						playerTurn = 0;
					}

					else if (0 == winner)
					{
						playerTurn = (playerTurn == 1) ? 2 : 1;

					}

					ShowTurn(hWnd, hdc);
				}

			}
			ReleaseDC(hWnd, hdc);

		}
	}
}

void Move(HWND hWnd, HDC hdc, int xPos, int yPos)
{
	if (mode >= 1)
	{
		//calling function for button
		index = GetCellNumberFromPoint(hWnd, xPos, yPos);

		//print out Value of cell clicked on
		if (NULL != hdc)
		{
			/*WCHAR temp[100];
			wsprintf(temp, L"Index = %d", index);
			TextOut(hdc, xPos, yPos, temp, lstrlen(temp));*/
			//get cell demensions
			if (index != -1)
			{
				RECT rcCell;

				//cell is taken no other player can take over
				if ((0 == gameBoard[index]) && GetCellRect(hWnd, index, &rcCell))
				{
					gameBoard[index] = playerTurn;
					FillRect(hdc, &rcCell, (playerTurn == 4) ? hbr3 : hbr1);

					winner = Winner(wins);
					if (winner == 1)
					{
						MessageBox(hWnd, L"Player 1 is the winnner!" , L"You Win!", MB_OK | MB_ICONINFORMATION);
						playerTurn = 0;

					}

					else if (3 == winner)
					{
						MessageBox(hWnd, L"No one wins!", L"It's a draw", MB_OK | MB_ICONEXCLAMATION);
						playerTurn = 0;
					}

					else if (0 == winner)
					{
						playerTurn = (playerTurn == 1) ? 4 : 1;

					}

					ShowTurn(hWnd, hdc);
				}

			}
			ReleaseDC(hWnd, hdc);

		}
	}
}


void PCMoves(HWND hWnd, HDC hdc, int xPos, int yPos)
{
	if (4 == playerTurn)
	{
		//calling function for button

		//print out Value of cell clicked on
		HDC hdc = GetDC(hWnd);
		if (NULL != hdc)
		{
			/*WCHAR temp[100];
			wsprintf(temp, L"Index = %d", index);
			TextOut(hdc, xPos, yPos, temp, lstrlen(temp));*/
			//get cell demensions
			RECT rcCell;

			//AI
			if (mode == 1)
			{
				do
				{
					index = rand() % 25;
				} while (1 == gameBoard[index] || 4 == gameBoard[index]);
			}
			else if (mode == 2)
			{
				//stoped here!
				
				int x = 0;

				for (int i = 0; i < ARRAYSIZE(cells) ; i += 4)
				{
					if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && gameBoard[cells[i]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i + 1]])
					{
						index = cells[i + 1];
					}
					else if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 1]] && gameBoard[cells[i]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i + 2]])
					{
						index = cells[i + 2];
					}
					else if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 1]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i + 3]])
					{
						index = cells[i + 3];
					}
					else if (4 == gameBoard[cells[i+1]] && gameBoard[cells[i+1]] == gameBoard[cells[i + 2]] && gameBoard[cells[i+1]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i]])
					{
						index = cells[i];
					}
					else if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 1]] &&  0 == gameBoard[cells[i+2]] && 1 == gameBoard[cells[i + 3]])
					{
						index = cells[i+2];
					}
					else if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i + 1]] && 1 == gameBoard[cells[i + 3]])
					{
						index = cells[i + 1];
					}
					else if (4 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i + 2]] && 1 == gameBoard[cells[i + 1]])
					{
						index = cells[i +2];
					}
					else if (1 == gameBoard[cells[i + 1]] && gameBoard[cells[i + 1]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i+2]] && gameBoard[i] !=4)
					{
						index = cells[i + 2];
					}
					else if (1 == gameBoard[cells[i+1]] && gameBoard[cells[i+1]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i]] && gameBoard[i+2] != 4)
					{
						index = cells[i];
					}
					else if (1 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i + 3]] && gameBoard[i+1] != 4)
					{
						index = cells[i + 3];
					}
					else if (1 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i + 1]] && gameBoard[i+3] != 4)
					{
						index = cells[i + 1];
					}
					else if (1 == gameBoard[cells[i + 2]] && gameBoard[cells[i + 2]] == gameBoard[cells[i + 3]] && 0 == gameBoard[cells[i + 1]] && gameBoard[i] != 4)
					{
						index = cells[i + 1];
					}
					else if (1 == gameBoard[cells[i+1]] && gameBoard[cells[i+1]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i]] && gameBoard[i+3] != 4)
					{
						index = cells[i];
					}
					else if (1 == gameBoard[cells[i + 1]] && gameBoard[cells[i + 1]] == gameBoard[cells[i + 2]] && 0 == gameBoard[cells[i+3]] && gameBoard[i] != 4)
					{
						index = cells[i + 3];
					}
					
					else if (1 == gameBoard[cells[i]] && gameBoard[cells[i]] == gameBoard[cells[i + 1]] && 0 == gameBoard[cells[i + 2]] && gameBoard[i+3] != 4)
					{
						index = cells[i + 2];
					}
					else
					{
						while (1 == gameBoard[index] || 4 == gameBoard[index])
							index = rand() % 25;
					}
					x = index;
				}

				if (count == 0)
				{
					while (1 == gameBoard[index] || 4 == gameBoard[index])
						index = rand() % 25;
				}

				count++;

			}


				//working on this

			//stoped here	



		//cell is taken no other player can take over
				if ((0 == gameBoard[index]) && GetCellRect(hWnd, index, &rcCell))
				{
					gameBoard[index] = playerTurn;
					FillRect(hdc, &rcCell, (playerTurn == 4) ? hbr3 : hbr1);

					winner = Winner(wins);
					if (winner == 4)
					{
						MessageBox(hWnd, L"AI is the winner!", L"You Lose!", MB_OK | MB_ICONINFORMATION);
						playerTurn = 0;

					}

					else if (3 == winner)
					{
						MessageBox(hWnd, L"No one wins!", L"It's a draw", MB_OK | MB_ICONEXCLAMATION);
						playerTurn = 0;
					}

					else if (0 == winner)
					{
						playerTurn = (playerTurn == 1) ? 4 : 1;

					}

					ShowTurn(hWnd, hdc);
				}

			}
			ReleaseDC(hWnd, hdc);
	}
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
		//create a brush to user as player
	case WM_CREATE:
	{
		hbr1 = CreateSolidBrush(RGB(255, 0, 0));
		hbr2 = CreateSolidBrush(RGB(0, 0, 255));
		hbr3 = CreateSolidBrush(RGB(0, 225, 0));
	}
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Parse the menu selections:
            switch (wmId)
            {
			case ID_NEWGAME:
			{
				int ret = MessageBox(hWnd, L"Are you sure you want to start a new game?", L"New Game", MB_YESNO | MB_ICONQUESTION);
				if (IDYES == ret)
				{
						playerTurn = 1;
						winner = 0;
						ZeroMemory(gameBoard, sizeof(gameBoard));
						InvalidateRect(hWnd, NULL, TRUE);
						UpdateWindow(hWnd);
						mode = 0;
				}
			}
			break;
			case ID_SINGLEPLAYER_EASY:
			{
							int ret = MessageBox(hWnd, L"Are you sure you want to start a new game?", L"New Game", MB_YESNO | MB_ICONQUESTION);
				if (IDYES == ret)
				{

						playerTurn = 1;
						winner = 0;
						ZeroMemory(gameBoard, sizeof(gameBoard));
						InvalidateRect(hWnd, NULL, TRUE);
						UpdateWindow(hWnd);
						mode = 1;
				}
			}
			break;
			case ID_SINGLEPLAYER_MEDIUM:
			{
				int ret = MessageBox(hWnd, L"Are you sure you want to start a new game?", L"New Game", MB_YESNO | MB_ICONQUESTION);
				if (IDYES == ret)
				{

						playerTurn = 1;
						winner = 0;
						ZeroMemory(gameBoard, sizeof(gameBoard));
						InvalidateRect(hWnd, NULL, TRUE);
						UpdateWindow(hWnd);
						mode = 2;

				}
			}
			break;
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;

	case WM_LBUTTONDOWN:
	{
		int xPos = GET_X_LPARAM(lParam);
		int yPos = GET_Y_LPARAM(lParam);
		HDC hdc = GetDC(hWnd);

		if (mode >= 1)
		{
			Move(hWnd, hdc, xPos, yPos);
		}
		else
			Moves(hWnd, hdc, xPos, yPos);
	}
		break;
	case WM_LBUTTONUP:
	{
		int xPos = GET_X_LPARAM(lParam);
		int yPos = GET_Y_LPARAM(lParam);

		HDC hdc = GetDC(hWnd);

		PCMoves(hWnd, hdc, xPos, yPos);
	}
	break;

	case WM_GETMINMAXINFO:
	{
		MINMAXINFO * pMinMax = (MINMAXINFO*)lParam;
		pMinMax->ptMinTrackSize.x = (CELL_SIZE * 7);
		pMinMax->ptMinTrackSize.y = (CELL_SIZE * 7) ;
	}
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
			RECT rc;

			if (GetGameBoard(hWnd, &rc))
			{
				RECT rcClient;
				if (GetClientRect(hWnd, &rcClient))
				{
					//display Player's name

					SetBkMode(hdc, TRANSPARENT);
					
					if (mode > 0)
					{
						SetTextColor(hdc, RGB(255, 0, 0));
						TextOut(hdc, 18, 20, szPlayer1, ARRAYSIZE(szPlayer1));
						SetTextColor(hdc, RGB(0, 255, 0));
						TextOut(hdc, rcClient.right - 80, 20, szPlayer3, ARRAYSIZE(szPlayer3));
					}
					if (mode == 0)
					{
						SetTextColor(hdc, RGB(255, 0, 0));
						TextOut(hdc, 18, 20, szPlayer1, ARRAYSIZE(szPlayer1));
						SetTextColor(hdc, RGB(0, 0, 255));
						TextOut(hdc, rcClient.right - 80, 20, szPlayer2, ARRAYSIZE(szPlayer2));
					}

					ShowTurn(hWnd, hdc);
				}
				//Remove boarders
				FillRect(hdc, &rc, (HBRUSH)GetStockObject(WHITE_BRUSH));
				//Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

			}

			for (int i = 1; i < 5; ++i)
			{
				//vertical lines
				Drawlines(hdc, rc.left + CELL_SIZE * i, rc.top, rc.left + CELL_SIZE *i, rc.bottom);

				//Horizantal line
				Drawlines(hdc, rc.left, rc.top + CELL_SIZE * i, rc.right, rc.top + CELL_SIZE * i);
			}
			for (int i = 0; i < 25; i++)
			{
				RECT rcCell;
				//action stays after re-size page
				if (0 != gameBoard[i] && GetCellRect(hWnd, i, &rcCell) && mode == 0 )
				{

						FillRect(hdc, &rcCell, (gameBoard[i] == 2) ? hbr2 : hbr1);

				}
				else if (0 != gameBoard[i] && GetCellRect(hWnd, i, &rcCell) && mode > 0)
				{
					FillRect(hdc, &rcCell, (gameBoard[i] == 4) ? hbr3 : hbr1);
				}

			}
            // TODO: Add any drawing code that uses hdc here...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
		DeleteObject(hbr1);
		DeleteObject(hbr2);
		DeleteObject(hbr3);
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}